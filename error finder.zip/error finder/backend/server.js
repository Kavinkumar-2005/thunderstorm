const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Serve Login Page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Handle login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'admin' && password === 'admin') {
    res.redirect('/enter-code.html');
  } else {
    res.send('Invalid login <a href="/">Try again</a>');
  }
});

// Handle code submission
app.post('/submit-code', (req, res) => {
  const code = req.body.codeInput;
  const fixedCode = code.replace(/\s{2,}/g, ' ');
  res.send(`
    <h1>Debugged Code</h1>
    <pre>${fixedCode}</pre>
    <a href="/enter-code.html">Back</a>
  `);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
