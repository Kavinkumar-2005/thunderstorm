// Basic login validation
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
      loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        // Simple check
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        if (username === 'admin' && password === 'admin') {
          window.location.href = 'enter-code.html';
        } else {
          alert('Invalid login!');
        }
      });
    }
  
    // Show debugged code
    const debuggedCode = document.getElementById('debuggedCode');
    if (debuggedCode) {
      const code = localStorage.getItem('userCode') || 'No code provided.';
      // Simulate debugging by just cleaning extra spaces
      const fixedCode = code.replace(/\s{2,}/g, ' ');
      debuggedCode.textContent = fixedCode;
    }
  });
  
  function goToResult() {
    const code = document.getElementById('codeInput').value;
    localStorage.setItem('userCode', code);
    window.location.href = 'result.html';
  }
  